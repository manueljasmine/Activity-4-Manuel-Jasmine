﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace jasminelogin
{
    public partial class DashboardForm : Form
    {
        public DashboardForm(string fullName)
        {
            Text = "JasmineLogin - Dashboard";
            Size = new Size(700, 480);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(240, 250, 244);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Label brand = new Label
            {
                Text = "JASMINELOGIN",
                Font = new Font("Segoe UI", 25, FontStyle.Bold),
                ForeColor = Color.FromArgb(20, 90, 50),
                Location = new Point(100, 65),
                Size = new Size(500, 55),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label welcome = new Label
            {
                Text = "Welcome, " + fullName + "!",
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = Color.FromArgb(35, 139, 82),
                Location = new Point(75, 170),
                Size = new Size(550, 60),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label message = new Label
            {
                Text = "You have successfully logged in.",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.Gray,
                Location = new Point(100, 240),
                Size = new Size(500, 35),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Button btnLogout = new Button
            {
                Text = "LOG OUT",
                Location = new Point(225, 320),
                Size = new Size(220, 48),
                BackColor = Color.FromArgb(20, 90, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                Cursor = Cursors.Hand
            };

            btnLogout.Click += (sender, e) =>
            {
                Close();
            };

            Controls.Add(brand);
            Controls.Add(welcome);
            Controls.Add(message);
            Controls.Add(btnLogout);
        }
    }
}
