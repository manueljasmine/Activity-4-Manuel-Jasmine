﻿
using System;
using System.Data;
using System.Data.OleDb;
using System.IO;

namespace jasminelogin
{
    public static class DatabaseHelper
    {
        // USE THE DATABASE IN THE MAIN PROJECT FOLDER
        private static readonly string DatabasePath =
            Path.GetFullPath(
                Path.Combine(
                    AppContext.BaseDirectory,
                    @"..\..\..\JasmineLogin.accdb"
                )
            );

        private static readonly string ConnectionString =
            $"Provider=Microsoft.ACE.OLEDB.12.0;" +
            $"Data Source={DatabasePath};" +
            "Persist Security Info=False;";

        public static string GetDatabasePath()
        {
            return DatabasePath;
        }

        // DATABASE CONNECTION
        public static OleDbConnection GetConnection()
        {
            if (!File.Exists(DatabasePath))
            {
                throw new FileNotFoundException(
                    "Database file not found:\n" + DatabasePath
                );
            }

            return new OleDbConnection(ConnectionString);
        }

        // TEST CONNECTION AND TABLE
        public static bool TestConnection()
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                using (OleDbCommand command = new OleDbCommand(
                    "SELECT COUNT(*) FROM [AppUsers]", connection))
                {
                    command.ExecuteScalar();
                }

                return true;
            }
        }

        // CHECK USERNAME
        public static bool UsernameExists(string username)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string query =
                    "SELECT COUNT(*) FROM [AppUsers] WHERE [Username] = ?";

                using (OleDbCommand command =
                    new OleDbCommand(query, connection))
                {
                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 50
                    ).Value = username.Trim();

                    return Convert.ToInt32(
                        command.ExecuteScalar()
                    ) > 0;
                }
            }
        }

        // REGISTER USER
        public static bool RegisterUser(
            string fullName,
            string username,
            string password)
        {
            if (string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrEmpty(password))
            {
                throw new ArgumentException(
                    "Please complete all registration fields."
                );
            }

            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                // CHECK DUPLICATE USERNAME
                if (UsernameExistsInConnection(connection, username))
                {
                    return false;
                }

                // HASH PASSWORD
                string passwordHash =
                    PasswordHasher.HashPassword(password);

                // INSERT RECORD
                string query =
                    "INSERT INTO [AppUsers] " +
                    "([FullName], [Username], [PasswordHash]) " +
                    "VALUES (?, ?, ?)";

                using (OleDbCommand command =
                    new OleDbCommand(query, connection))
                {
                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 100
                    ).Value = fullName.Trim();

                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 50
                    ).Value = username.Trim();

                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 255
                    ).Value = passwordHash;

                    int rowsAffected = command.ExecuteNonQuery();

                    return rowsAffected == 1;
                }
            }
        }

        private static bool UsernameExistsInConnection(
            OleDbConnection connection,
            string username)
        {
            string query =
                "SELECT COUNT(*) FROM [AppUsers] WHERE [Username] = ?";

            using (OleDbCommand command =
                new OleDbCommand(query, connection))
            {
                command.Parameters.Add(
                    "?", OleDbType.VarWChar, 50
                ).Value = username.Trim();

                return Convert.ToInt32(
                    command.ExecuteScalar()
                ) > 0;
            }
        }

        // FIND USER FOR LOGIN
        public static (string FullName, string PasswordHash)?
            FindUser(string username)
        {
            using (OleDbConnection connection = GetConnection())
            {
                connection.Open();

                string query =
                    "SELECT [FullName], [PasswordHash] " +
                    "FROM [AppUsers] WHERE [Username] = ?";

                using (OleDbCommand command =
                    new OleDbCommand(query, connection))
                {
                    command.Parameters.Add(
                        "?", OleDbType.VarWChar, 50
                    ).Value = username.Trim();

                    using (OleDbDataReader reader =
                        command.ExecuteReader())
                    {
                        if (reader != null && reader.Read())
                        {
                            return (
                                reader["FullName"].ToString() ?? "",
                                reader["PasswordHash"].ToString() ?? ""
                            );
                        }
                    }
                }

                return null;
            }
        }
    }
}
